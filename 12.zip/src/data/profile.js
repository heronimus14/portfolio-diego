// EDIT BAGIAN INI UNTUK MENGGANTI DATA UTAMA PROFILE
export const profileData = {
  name: "Nama Kamu", // Ganti dengan nama lengkap atau nama panggilanmu
  role: "Creative Frontend Developer", // Ganti dengan role profesi kamu
  tagline: "I build clean digital experiences through web development, design, and creative storytelling.", // Tagline singkat yang menarik
  bio: "Saya menggabungkan teknologi, desain, dan pengalaman organisasi untuk membangun identitas digital yang profesional, modern, dan mudah diingat. Aktif di berbagai kegiatan membuat saya terbiasa bekerja dalam tim dan komunikatif.", // Deskripsi diri
  location: "Indonesia",
  
  // Ganti placeholder gambar dengan path gambar aslimu di folder public/images/
  // Contoh: "/images/foto-saya.jpg"
  photo: "https://via.placeholder.com/400x400/111/38bdf8?text=Profile", 
  
  // Kontak dan Social Media
  email: "emailkamu@gmail.com",
  whatsapp: "6281234567890", // Format nomor WA (awali dengan 62)
  instagram: "https://instagram.com/username", // Link ke IG
  github: "https://github.com/username", // Link ke GitHub
  linkedin: "https://linkedin.com/in/username", // Link ke LinkedIn
  cv: "/cv.pdf", // Path ke file CV kamu di public folder
  
  // Angka untuk About Section
  stats: {
    webProjects: 5,
    creativeActivities: 12,
    organizationExperience: 3,
    achievements: 4
  }
};
