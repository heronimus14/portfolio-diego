// EDIT BAGIAN INI UNTUK MENAMBAH ATAU MENGUBAH PENGALAMAN LUAR KAMPUS/CODING
export const experiencesData = [
  {
    id: 1,
    title: "Wedding Choir Performance",
    category: "Creative Experience",
    role: "Choir Member",
    image: "https://via.placeholder.com/600x400/111/38bdf8?text=Wedding+Choir", // Ganti path gambar
    description: "Terlibat dalam paduan suara wedding yang melatih kerja sama tim, disiplin latihan, kepercayaan diri, dan kemampuan tampil profesional.",
    skills: ["Teamwork", "Discipline", "Confidence"]
  },
  {
    id: 2,
    title: "Big Event Committee",
    category: "Organization",
    role: "Committee Member",
    image: "https://via.placeholder.com/600x400/111/0284c7?text=Event+Committee",
    description: "Berpartisipasi dalam kepanitiaan acara besar, termasuk koordinasi tim, komunikasi teknis, dan pengelolaan kegiatan.",
    skills: ["Leadership", "Communication", "Responsibility"]
  },
  {
    id: 3,
    title: "National IT Competition",
    category: "Achievement",
    role: "Participant",
    image: "https://via.placeholder.com/600x400/111/4c1d95?text=Competition",
    description: "Mengikuti kompetisi tingkat nasional untuk mengembangkan kemampuan, mental bertanding, problem solving, dan keberanian mencoba tantangan baru.",
    skills: ["Growth Mindset", "Problem Solving", "Adaptability"]
  }
];
