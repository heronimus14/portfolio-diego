// EDIT BAGIAN INI UNTUK MENGUBAH TIMELINE PERJALANANMU
export const timelineData = [
  {
    id: 1,
    year: "2021",
    title: "Memulai Perjalanan IT",
    description: "Mulai masuk kuliah jurusan IT dan belajar dasar pemrograman seperti HTML, CSS, dan algoritma dasar."
  },
  {
    id: 2,
    year: "2022",
    title: "Bergabung Organisasi & Kepanitiaan",
    description: "Mulai aktif di Himpunan Mahasiswa dan menjadi panitia divisi Publikasi & Dokumentasi untuk event besar kampus."
  },
  {
    id: 3,
    year: "2023",
    title: "Eksplorasi Frontend & Kegiatan Kreatif",
    description: "Fokus belajar React dan Tailwind CSS. Di luar kampus, bergabung dengan grup paduan suara wedding untuk mengasah hobi dan team work."
  },
  {
    id: 4,
    year: "2024",
    title: "Membangun Project & Mengikuti Lomba",
    description: "Mulai membuat beberapa portfolio website dan memenangkan lomba desain web. Terus mengembangkan personal branding sebagai Creative Frontend Developer."
  }
];
