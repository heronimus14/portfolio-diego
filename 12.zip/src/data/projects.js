// EDIT BAGIAN INI UNTUK MENAMBAH ATAU MENGUBAH PROJECT
export const projectsData = [
  {
    id: 1,
    title: "Personal Portfolio Website",
    role: "Frontend Developer",
    tools: ["React", "Tailwind CSS", "Framer Motion"],
    image: "https://via.placeholder.com/600x400/111/38bdf8?text=Project+1", // Ganti dengan path gambarmu
    description: "Website portfolio responsive untuk membangun personal branding dengan tampilan modern dan interaktif.",
    liveUrl: "#", // Link ke website yang sudah live
    githubUrl: "#" // Link ke source code GitHub
  },
  {
    id: 2,
    title: "Company Landing Page",
    role: "UI Designer & Frontend Developer",
    tools: ["React", "Tailwind CSS"],
    image: "https://via.placeholder.com/600x400/111/0284c7?text=Project+2",
    description: "Landing page modern dengan struktur konten yang jelas, CTA kuat, dan desain responsive.",
    liveUrl: "#",
    githubUrl: "#"
  },
  {
    id: 3,
    title: "Event Dashboard UI",
    role: "UI/UX Designer",
    tools: ["Figma", "Prototyping"],
    image: "https://via.placeholder.com/600x400/111/4c1d95?text=Project+3",
    description: "Desain antarmuka dashboard untuk manajemen event yang intuitif dan mudah digunakan oleh penyelenggara acara.",
    liveUrl: "#",
    githubUrl: ""
  }
];
