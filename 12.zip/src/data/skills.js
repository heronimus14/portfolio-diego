// EDIT BAGIAN INI UNTUK MENGUBAH DAFTAR SKILL
export const skillsData = {
  technical: [
    "React", "Tailwind CSS", "JavaScript (ES6+)", "Vite", 
    "HTML5 & Semantic", "CSS3", "PHP", "Bootstrap", "Git & GitHub"
  ],
  design: [
    "UI Design", "Figma", "Prototyping", "Layouting", 
    "Visual Branding", "Social Media Design", "Color Theory"
  ],
  soft: [
    "Teamwork", "Communication", "Leadership", "Discipline", 
    "Public Speaking", "Event Coordination", "Problem Solving"
  ]
};
