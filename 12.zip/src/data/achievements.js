// EDIT BAGIAN INI UNTUK MENAMBAH PENGHARGAAN, SERTIFIKASI, ATAU LOMBA
export const achievementsData = [
  {
    id: 1,
    title: "1st Place Web Design Competition",
    year: "2024",
    type: "Competition",
    description: "Meraih juara pertama dalam lomba desain web tingkat universitas dengan fokus pada aksesibilitas dan UI/UX modern.",
    image: "https://via.placeholder.com/600x400/111/38bdf8?text=Achievement+1"
  },
  {
    id: 2,
    title: "Frontend Developer Certification",
    year: "2023",
    type: "Certification",
    description: "Menyelesaikan program sertifikasi dengan hasil memuaskan dan membuat project akhir e-commerce.",
    image: "https://via.placeholder.com/600x400/111/0284c7?text=Achievement+2"
  },
  {
    id: 3,
    title: "Best Creative Team - Annual Choir",
    year: "2023",
    type: "Award",
    description: "Mendapatkan penghargaan sebagai tim paling kreatif dalam mengonsep penampilan dan koreografi.",
    image: "https://via.placeholder.com/600x400/111/4c1d95?text=Achievement+3"
  }
];
