import { motion } from 'framer-motion';
import { experiencesData } from '../data/experiences';

const Experiences = () => {
  return (
    <section id="experiences" className="py-20 pl-6 md:px-6 relative z-10 w-full overflow-hidden scroll-mt-20">
      <div className="max-w-6xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-100px" }}
          className="mb-12 pr-6 md:pr-0"
        >
          <h2 className="text-3xl md:text-5xl font-bold text-white mb-4 tracking-tight">
            Beyond The <span className="text-gradient">Screen</span>
          </h2>
          <p className="text-gray-400 max-w-2xl text-lg">
            Pengalaman saya di luar dunia coding, termasuk organisasi, kepanitiaan, dan kegiatan kreatif.
          </p>
        </motion.div>

        {/* Horizontal Scroll on Mobile, Grid on Desktop */}
        <div className="flex overflow-x-auto hide-scrollbar gap-6 pb-8 snap-x snap-mandatory md:grid md:grid-cols-3 md:snap-none md:overflow-visible pr-6 md:pr-0">
          {experiencesData.map((exp, index) => (
            <motion.div
              key={exp.id}
              initial={{ opacity: 0, x: 50 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true, margin: "-50px" }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              className="min-w-[85vw] sm:min-w-[320px] md:min-w-0 snap-center glass-card rounded-3xl overflow-hidden group relative transform transition-all duration-300 hover:-translate-y-2 hover:border-accent/40"
            >
              {/* Image & Gradient */}
              <div className="h-48 relative overflow-hidden">
                <img 
                  src={exp.image} 
                  alt={exp.title} 
                  className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-primary via-primary/50 to-transparent opacity-90 group-hover:opacity-70 transition-opacity duration-300"></div>
                
                <div className="absolute top-4 left-4 bg-accent/20 backdrop-blur-md border border-accent/30 text-accent-light text-xs font-bold px-3 py-1 rounded-full">
                  {exp.category}
                </div>
              </div>

              {/* Content */}
              <div className="p-6 relative z-10 -mt-10">
                <div className="bg-white/10 backdrop-blur-md border border-white/10 px-3 py-1 rounded-full text-xs font-semibold text-white inline-block mb-3 shadow-lg">
                  {exp.role}
                </div>
                
                <h3 className="text-xl font-bold text-white mb-3 tracking-wide">{exp.title}</h3>
                
                <p className="text-gray-400 text-sm leading-relaxed mb-6">
                  {exp.description}
                </p>

                {/* Skills */}
                <div className="flex flex-wrap gap-2">
                  {exp.skills.map((skill, i) => (
                    <span key={i} className="text-xs font-medium px-2.5 py-1 rounded-full bg-white/5 text-gray-300 border border-white/10">
                      {skill}
                    </span>
                  ))}
                </div>
              </div>
              
              {/* Hover Glow */}
              <div className="absolute inset-0 border-2 border-transparent group-hover:border-white/10 rounded-3xl pointer-events-none transition-colors duration-300"></div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Experiences;
